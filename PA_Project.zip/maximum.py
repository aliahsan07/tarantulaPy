def maximum(x,y,z):
	m = 0		#bug
	if (x > m):
		m = x
	if (y > x):
		m = y
	if (z > y):
		m = z
	#print "Middle Number is: " + str(m)
	return m