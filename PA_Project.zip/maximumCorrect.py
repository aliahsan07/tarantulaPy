def maximum(x):
	m = x[0]

	for i in x:
		if i>m:
			m = i
	

	return m




