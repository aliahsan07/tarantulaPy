HOW TO RUN

python tarantula.py <Source_Code> <Test_Suite_File>

for example if you want to test tarantula on file mid.py:
RUN
python tarantula.py mid.py testCaseMid


This would give the 10 most suspicious lines as output. A detailed report of every line is generated in the output file output.txt.

